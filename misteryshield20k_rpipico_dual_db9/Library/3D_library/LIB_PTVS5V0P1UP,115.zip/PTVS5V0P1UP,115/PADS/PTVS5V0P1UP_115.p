*PADS-LIBRARY-PART-TYPES-V9*

PTVS5V0P1UP_115 PMEG3050EP115 I ANA 7 1 0 0 0
TIMESTAMP 2026.01.27.20.50.09
"Mouser Part Number" 771-PTVS5V0P1UP115
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PTVS5V0P1UP115?qs=5eMHoInnifR6YsgTVxSrGQ%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PTVS5V0P1UP,115
"Description" PTVS5V0P1UP - 600 W Transient Voltage Suppressor
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PTVSXP1UP_SER.pdf
"Geometry.Height" 1mm
GATE 1 2 0
PTVS5V0P1UP_115
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
972085/1876128/2.50/2/2/Diode ESD (Uni-directional)
